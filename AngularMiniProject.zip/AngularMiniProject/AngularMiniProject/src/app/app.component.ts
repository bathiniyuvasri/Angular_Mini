import { Component } from '@angular/core';
'@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'AngularMiniProject';
  
  employees = [
    {id:"101", name:"Suma", salary:"10000", department:"Java"},
    {id:"102", name:"Yuva", salary:"60000", department:"python"},
    {id:"103", name:"Sravan", salary:"45670", department:"CP"},
    {id:"104", name:"Seetha", salary:"56700", department:"CPP"},                 
  ];
  model:any={};
  model2:any={};
  msg:any="";
  addEmployee(){
    this.employees.push(this.model);
    this.model = {};
    this.msg = "Record is successfully added"; 

  }
  deleteEmployee(i:number){
    this.employees.splice(i,1);
    this.msg = "Record is successfully deleted";
    
  }
  myValue:any;
  editEmployee(k: any){
    this.model2.id = this.employees[k].id;
    this.model2.name = this.employees[k].name;
    this.model2.salary = this.employees[k].salary;
    this.model2.department = this.employees[k].department;
    this.myValue = k;

  }
  updateEmployee(){
    let eInfo= this.myValue;
    for(let i=0; i<this.employees.length;i++){
      if(i==eInfo){
        this.employees[i]= this.model2;
        this.model2 = {};
        this.msg = "Record is successfully updated";
      }

    }

  }
  clickMe(){
    this.msg = "";
  }
}
